import { LayoutItemDirective } from './layout-item.directive';

describe('LayoutItemDirective', () => {
  it('should create an instance', () => {
    const directive = new LayoutItemDirective();
    expect(directive).toBeTruthy();
  });
});
